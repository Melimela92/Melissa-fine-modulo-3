CREATE DATABASE ToyCenterMelissa 

USE ToyCenterMelissa
-- ToyCenterMelissa � una catena di giocattoli aperta in vari Stati d'Europa

-- creo la tabella Categoria
CREATE TABLE Categoria (
    IDCategoria INT PRIMARY KEY,
    Descrizione VARCHAR(50)
);

-- Popolo la tabella con le categorie presenti negli store

INSERT INTO Categoria (IDCategoria, Descrizione) VALUES 
(1, 'Peluches'),
(2, 'Bambole'),
(3, 'Giochi da tavola'),
(4, 'Videogames');

-- Creo la tabella Prodotto 
CREATE TABLE Prodotto (
    IDProdotto INT PRIMARY KEY,
    Nome_prodotto VARCHAR(255),
    IDCategoria INT,
    Prezzo_unitario DECIMAL(10, 2),
    QntStock INT,
    FOREIGN KEY (IDCategoria) REFERENCES Categoria(IDCategoria)
);

-- Popolo la tabella prodotto con ID del prodotto, ID della Categoria a cui appartiene, Nome del gioco, Prezzo del singolo gioco, Quantit� presente nel magazzino
INSERT INTO Prodotto (IDProdotto, IDCategoria, Nome_prodotto, Prezzo_unitario, QntStock) VALUES 
(1, 2, 'Barbie Raperonzolo', 11.99, 6),
(2, 4, 'Sonic 3', 55.70, 8),
(3, 3, 'Monopoly', 20.99, 12),
(4, 3, 'Labirinto', 21.99, 4),
(5, 2, 'Cicciobello bua', 32.99, 5),
(6, 1, 'Pikachu', 24.99, 3),
(7, 1, 'Orsetto', 17.99, 2),
(8, 2, 'Moster High', 21.99, 7),
(9, 3, 'Cluedo', 27.80, 8),
(10, 4, 'GTA Sant Andreas', 55.20, 3);

-- Creo la tabella Area che mi serve per specificare le aree di appartenenza di ogni stato
CREATE TABLE Area (
    Nome_Area VARCHAR(50) PRIMARY KEY
);

-- popolo la tabella con le aree dell'europa
INSERT INTO Area (Nome_Area) VALUES 
('Europa Settentrionale'),
('Europa Centrale'),
('Europe Orientale'),
('Europa Meridionale'),
('Europa Occidentale');

-- popolo la tabella regione
CREATE TABLE Regione (
    IDRegione INT PRIMARY KEY,
    Nome_Area VARCHAR(50),
    Stato VARCHAR(50),
    FOREIGN KEY (Nome_Area) REFERENCES Area(Nome_Area)
);

INSERT INTO Regione (IDRegione, Nome_Area, Stato) VALUES
(1, 'Europa Meridionale', 'Italia'),
(2, 'Europa Meridionale', 'Portogallo'),
(3, 'Europa Occidentale', 'Francia'),
(4, 'Europa Occidentale', 'Germania'),
(5, 'Europe Orientale', 'Ungheria'),
(6, 'Europe Orientale', 'Romania'),
(7, 'Europa Settentrionale', 'Norvegia'),
(8, 'Europa Settentrionale', 'Lituania'),
(9, 'Europa Centrale', 'Austria'),
(10, 'Europa Centrale', 'Slovenia');

-- Creo la tabella Vendite 
CREATE TABLE Vendite (
    IDVendita INT PRIMARY KEY,
    IDprodotto INT,
    IDRegione INT,
    Data_ordine DATE,
    Prezzo_unitario DECIMAL(10, 2),
    Qnt_sold INT,
    Importo_TOT DECIMAL(10, 2),
    FOREIGN KEY (IDprodotto) REFERENCES Prodotto(IDProdotto),
    FOREIGN KEY (IDRegione) REFERENCES Regione(IDRegione)
);


/* popolo la tabella vendite con ID della transazione, La regione dove viene effettuata la vendita, il prodotto venduto, 
la data della vendita, il prezzo dell'articolo venduto, la quantit� di articoli venduti, l'importo totale della vendita */

INSERT INTO Vendite (IDVendita, IDRegione, IDProdotto, Data_ordine, Prezzo_unitario, Qnt_sold, Importo_TOT) VALUES
(1, 3, 5, '2023-01-20', 32.99, 2, 65.98),
(2, 4, 7, '2022-08-04', 17.99, 4, 71.96),
(3, 5, 4, '2023-10-09', 21.99, 9, 197.91),
(4, 7, 8, '2023-05-07', 21.99, 3, 65.97),
(5, 8, 9, '2022-01-14', 27.80, 8, 222.40),
(6, 8, 9, '2023-06-10', 27.80, 6, 166.80),
(7, 1, 1, '2023-08-15', 11.99, 5, 59.95),
(8, 2, 1, '2022-10-18', 11.99, 1, 11.99),
(9, 3, 9, '2023-03-06', 27.80, 7, 194.60),
(10, 8, 2, '2023-02-14', 55.70, 5, 278.50);

-- Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l�univocit� dei valori di ciascuna PK (una query per tabella implementata).


SELECT 
	COUNT(*)	AS Conteggio, 
	IDCategoria
FROM Categoria
GROUP BY IDCategoria
HAVING COUNT(*) > 1;



SELECT 
	COUNT(*)	AS Conteggio, 
	IDProdotto
FROM Prodotto
GROUP BY IDProdotto
HAVING COUNT(*) > 1;



SELECT 
	COUNT(*)	AS Conteggio, 
	IDRegione
FROM Regione
GROUP BY IDRegione
HAVING COUNT(*) > 1;



SELECT 
	COUNT(*)	AS Conteggio, 
	Nome_Area
FROM Area
GROUP BY Nome_Area
HAVING COUNT(*) > 1;



SELECT 
	COUNT(*)	AS Conteggio, 
	IDVendita
FROM Vendite
GROUP BY IDVendita
HAVING COUNT(*) > 1;


/*Esporre l�elenco delle transazioni indicando nel result set il codice prodotto, la data, il nome del prodotto, 
la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato 
in base alla condizione che siano passati pi� di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False) */

SELECT	
	p.IDProdotto,
	Nome_prodotto,
	c.Descrizione				AS Categoria,
	a.Nome_Area,
	Stato,
	CASE WHEN DATEDIFF(DAY, v.Data_ordine, GETDATE()) > 180 THEN 1 ELSE 0 END AS 'Passati180Giorni'
FROM Prodotto					AS p
	JOIN Categoria				AS c
	ON c.IDCategoria = p.IDCategoria 
	JOIN Vendite				AS v
	ON v.IDprodotto = p.IDProdotto 
	JOIN Regione				AS r
	ON r.IDRegione = v.IDRegione
	JOIN Area					AS a
	ON a.Nome_Area = r.Nome_Area ;


-- Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT 
		p.IDprodotto,
		p.Nome_prodotto,
		YEAR(v.Data_ordine) AS Anno,
		SUM(v.Importo_TOT)  AS FatturatoTotale
FROM Prodotto			AS p
JOIN Vendite			AS v
ON p.IDProdotto = v.IDProdotto
GROUP BY
    p.IDProdotto,
    p.Nome_prodotto,
    YEAR(v.Data_ordine);


-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT
    r.Stato,
    YEAR(v.Data_ordine)			AS Anno,
    SUM(v.Importo_TOT)			AS FatturatoTotale
FROM
    Regione						AS r
    JOIN Vendite				AS v 
	ON r.IDRegione = v.IDRegione
GROUP BY
    r.Stato,
    YEAR(v.Data_ordine)
ORDER BY
    YEAR(v.Data_ordine) ASC,
    SUM(v.Importo_TOT) DESC;

-- Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?

SELECT*
FROM Vendite
SELECT *
FROM Categoria

SELECT 
		c.Descrizione		AS Categoria,
		SUM (v.Qnt_sold)	AS Venduto
FROM Categoria				AS c
JOIN Prodotto				AS p
ON p.IDCategoria = c.IDCategoria
JOIN Vendite				AS v
ON p.IDProdotto = v.IDprodotto
GROUP BY 
	c.Descrizione
ORDER BY SUM (v.Qnt_sold) DESC


-- Giochi da tavola � la categoria di prodotti pi� richiesti dal mercato 


-- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
SELECT *
FROM Prodotto

SELECT p.IDProdotto, p.Nome_prodotto 
FROM Prodotto					AS p
LEFT JOIN Vendite					AS v
ON p.IDProdotto = v.IDprodotto
WHERE v.IDprodotto IS NULL 


-- seconda alternativa

SELECT
    IDProdotto,
    Nome_prodotto
FROM
    Prodotto
WHERE
    IDProdotto NOT IN (
					SELECT DISTINCT IDprodotto 
					FROM Vendite);

-- Sono 3 prodotti invenduti Monopoly, Pikachu, GTA Sant Andreas

-- Esporre l�elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita pi� recente)

SELECT
    p.IDProdotto,
    p.Nome_prodotto,
    MAX(v.Data_ordine)			AS DataVendita
FROM
    Prodotto					AS p
    JOIN Vendite				AS v 
	ON p.IDProdotto = v.IDprodotto
GROUP BY
    p.IDProdotto, p.Nome_prodotto
ORDER BY MAX(v.Data_ordine) DESC;

-- la query mostra tutto l'elenco dei prodotti in ordine descrescente 

SELECT TOP 5
    p.IDProdotto,
    p.Nome_prodotto,
	v.Data_ordine
FROM
    Prodotto					AS p
    JOIN Vendite				AS v 
	ON p.IDProdotto = v.IDprodotto
ORDER BY v.Data_ordine DESC


/* Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� 
delle informazioni utili (codice prodotto, nome prodotto, nome categoria) */

CREATE VIEW VistaProdottiToyMels AS
SELECT
    p.IDProdotto			AS CodiceProdotto,
    p.Nome_prodotto			AS NomeProdotto,
    c.Descrizione			AS NomeCategoria
FROM
    Prodotto				AS p
    JOIN Categoria			as c 
	ON p.IDCategoria = c.IDCategoria;

-- Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche


SELECT * 
FROM Regione


CREATE VIEW VistaGeografToyMels AS 
SELECT
    IDRegione					AS CodiceRegione,
	Nome_Area					AS Zona,
	Stato						AS Paese 
FROM
    Regione

-- Esercizio opzionale: ottenute le viste per la costruzione delle dimensioni di analisi prodotto (punto 8)  e area geografica (punto 9), implementa un modello logico in Power Query e costruisci un report per l�analisi delle vendite

